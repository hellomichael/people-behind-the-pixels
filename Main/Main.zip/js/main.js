$(function() {
    'use strict';
});