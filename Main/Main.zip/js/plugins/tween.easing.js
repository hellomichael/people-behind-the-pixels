TWEEN.Easing.Deceleration = {};

TWEEN.Easing.Deceleration.InOut = function(k) {




};