/******************************
* Extend Scene Prototype
******************************/
var SequenceJakeArchibald = function() {
    this.sequence = [];
    this.init();
};

SequenceJakeArchibald.prototype = new Sequence();

/******************************
* Add Objects
******************************/
SequenceJakeArchibald.prototype.init = function() {
    // Three.js
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(45, window.innerWidth/window.innerHeight, 1, 50);
    renderator.reset(this.scene, this.camera);

    // Materials
    this.lineMaterial = new THREE.LineBasicMaterial({color: 'white'});
    this.basicMaterial = new THREE.MeshBasicMaterial ({color: 'white', opacity: 1, transparent: true,});
    this.lightMaterial = new THREE.MeshLambertMaterial({color: 'white', opacity: 1, transparent: true});
    this.edgeMaterial = new THREE.MeshBasicMaterial ({color: 'white', opacity: 1, transparent: true, wireframe: true});
    this.wireFrameMaterial = new THREE.MeshBasicMaterial ({color: 'white', opacity: 1, transparent: true, wireframe: true});

    // Lights
    this.directionalLight = new THREE.DirectionalLight(0xFFFFFF);
    this.directionalLight.position.set(0, 0.5, 0).normalize();
    this.scene.add(this.directionalLight);

    this.directionalLight = new THREE.DirectionalLight(0xFFFFFF);
    this.directionalLight.position.set(0, -0.05, 0).normalize();
    this.scene.add(this.directionalLight);

    // Camera Positioning
    this.camera.position.z = 8;

    // Objects
    this.icosahedron1 = new Icosahedron(4.5, 2, 0, 3);

    this.scene.add(this.icosahedron1);
    //this.scene.add(this.icosahedron2);
};

/******************************
* Add Animations
******************************/
SequenceJakeArchibald.prototype.rotateIcosahedron = function(icosahedron, rotation, duration, easing) {
    new TWEEN.Tween({rotation: 0})
        .to({rotation: rotation}, duration)
        .onUpdate(function (time) {
            icosahedron.rotation.x = this.rotation;
            icosahedron.rotation.y = this.rotation;
            icosahedron.rotation.z = this.rotation;
        })
    .start();
};

/******************************
* Initialize New Scene
******************************/
var sequenceJakeArchibald = new SequenceJakeArchibald();

/******************************
* Add Sequences
******************************/
var speaker = new Glitch ('JAKE ARCHIBALD', -500, -100);
sequenceJakeArchibald.addEvent('00:44:00', function() {speaker.animateIn()});
sequenceJakeArchibald.addEvent('00:50:00', function() {speaker.animateOut()})

sequenceJakeArchibald.addEvent('00:40:00', sequenceJakeArchibald.rotateIcosahedron, [sequenceJakeArchibald.icosahedron1, 180*Math.PI/180, 30000, TWEEN.Easing.Quadratic.InOut]);

sequenceJakeArchibald.addEvent('00:40:00', sequenceJakeArchibald.cameraZoom, [sequenceJakeArchibald.camera, 2, 1, 7, 1000, TWEEN.Easing.Quadratic.InOut]);

/******************************
* Add Sequences
******************************/
sequences.push(sequenceJakeArchibald);