// PBTB includes
//= src/namespace.js
//= src/utilities.js
//= src/audio.js
//= src/glitch.js
//= src/renderator.js
//= src/sequence.js
//= src/ring.js
//= src/icosahedron.js

// Shader stuff
//= src/shaders/CopyShader.js
//= src/shaders/EffectComposer.js
//= src/shaders/MaskPass.js
//= src/shaders/ConvolutionShader.js
//= src/shaders/BloomPass.js
//= src/shaders/RenderPass.js
//= src/shaders/ShaderPass.js
//= src/shaders/FilmPass.js
//= src/shaders/FilmShader.js
//= src/shaders/FXAAShader.js
//= src/shaders/BokehShader.js
//= src/shaders/BokehPass.js


// People Behind the Pixels
var peopleBehindthePixels = (function () {

    'use strict';

    var sequences = [];
    var screenWidth, screenHeight;
    var renderator = new Renderator();
    var prevTimestamp;
    var $stats;


    // Initialisation
    var init = function (playtime) {
        $stats = $('#stats');

        if (playtime === undefined) playtime = 0.0;

        // Import sequences
        // src/sequences/bill-scott.js
        //= src/sequences/jake-archibald.js

        // Load audio
        pbtp.audio.init('shared/audio/music.mp3');
        pbtp.audio.seek('00:40:00');
        pbtp.audio.mute();

        mainLoop(0);
    };


    var mainLoop = function(timestamp) {
        // Determine delta
        if (timestamp == undefined)
            prevTimestamp = timestamp = 0;
        var delta = (timestamp - prevTimestamp) / 1000.0;
        prevTimestamp = timestamp;

        // Updates
        updateSequence(pbtp.audio.getCurrentTime(), delta);
        TWEEN.update(timestamp);

        // Render
        renderator.render(delta);

        // Set callback
        requestAnimationFrame(mainLoop);
    };


    var updateSequence = function (currentTimeAudio, delta) {
        // Refactor to only play one scene at a time
        for (var i = 0; i < sequences.length; i++) {
            sequences[i].update(delta);
            sequences[i].play(currentTimeAudio);
        }

        $stats.html(pbtp.utilities.convertToTimecode(currentTimeAudio));
    };


    return {
        init: init
    };
}());

$(window).load(function() {
    peopleBehindthePixels.init();
});