module.exports.reverse = function(str) {
	'use strict';

	return str.split('').reverse().join('');
};